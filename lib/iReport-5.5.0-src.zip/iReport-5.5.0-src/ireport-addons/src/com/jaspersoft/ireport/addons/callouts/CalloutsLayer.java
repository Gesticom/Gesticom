/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.jaspersoft.ireport.addons.callouts;

import com.jaspersoft.ireport.designer.AbstractReportObjectScene;
import org.netbeans.api.visual.widget.LayerWidget;

/**
 *
 * @version $Id: CalloutsLayer.java 0 2010-01-14 14:45:55 CET gtoffoli $
 * @author Giulio Toffoli (giulio@jaspersoft.com)
 *
 */
public class CalloutsLayer extends LayerWidget {

    public CalloutsLayer(AbstractReportObjectScene scene)
    {
        super(scene);
    }
}
